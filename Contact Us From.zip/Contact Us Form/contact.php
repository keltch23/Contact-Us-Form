<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if (isset($_POST['name'])    &&
    isset($_POST['email'])   &&
    isset($_POST['subject']) &&
    isset($_POST['text'])) {
    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact']; // <-- Add this line
    $subject = $_POST['subject'];
    $text = $_POST['text'];
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $em = "Invalid email format";
        header("Location: index.php?error=$em");
        exit();
    }

    if (empty($name) || empty($subject) || empty($text) ) {
        $em = "Fill out all required entry fields";
        header("Location: index.php?error=$em");
        exit();
    }

    // --- Save to database ---
    $conn = new mysqli("localhost", "root", "", "proagromark");
    if ($conn->connect_error) {
        $em = "Database connection failed";
        header("Location: index.php?error=$em");
        exit();
    }
    $stmt = $conn->prepare("INSERT INTO contacts (name, email, contact, subject, message, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssss", $name, $email, $contact, $subject, $text);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    // --- End save to database ---

    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();                               
        $mail->Host = 'smtp.gmail.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username= 'kelvinknkoma86@gmail.com';
        $mail->Password = 'vjdf rqqx qoyd uadk'; 
        $mail->SMTPSecure = "ssl";          
        $mail->Port       = 465;                                  
        $mail->setFrom($email, $name);   
        $mail->addAddress('kelvinknkoma86@gmail.com'); 

        $mail->isHTML(true);                             
        $mail->Subject = $subject;
        $mail->Body    = "
               <h3>Contact Form</h3>
               <p><strong>Name</strong>: $name</p>
               <p><strong>Email</strong>: $email</p>
               <p><strong>Contact</strong>: $contact</p>
               <p><strong>Subject</strong>: $subject</p>
               <p><strong>Message</strong>: $text</p>
                         ";
        $mail->send();
        echo "success";
        exit();
    } catch (Exception $e) {
        $em = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        header("Location: index.php?error=$em");
    }
}