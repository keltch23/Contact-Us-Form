<?php
header("Content-Type: text/plain");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['email'])) {
        $email = trim($_POST['email']);

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo "Invalid email format";
            exit();
        }

        // Connect to database
        $conn = new mysqli("localhost", "root", "", "proagromark");
        if ($conn->connect_error) {
            http_response_code(500);
            echo "Database connection failed";
            exit();
        }

        // Prevent duplicate email
        $check = $conn->prepare("SELECT id FROM newsletter WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            echo "Already subscribed";
            $check->close();
            $conn->close();
            exit();
        }
        $check->close();

        // Insert new email
        $stmt = $conn->prepare("INSERT INTO newsletter (email, subscribed_at) VALUES (?, NOW())");
        if (!$stmt) {
            http_response_code(500);
            echo "Prepare failed: " . $conn->error;
            exit();
        }

        $stmt->bind_param("s", $email);
        if ($stmt->execute()) {
            echo "success";
        } else {
            http_response_code(500);
            echo "Insert failed: " . $stmt->error;
        }
        $stmt->close();
        $conn->close();
        exit();
    } else {
        http_response_code(400);
        echo "No email provided";
        exit();
    }
} else {
    http_response_code(405);
    echo "Invalid request method";
    exit();
}
