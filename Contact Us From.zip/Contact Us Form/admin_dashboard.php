
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | Pro Agro Mark Consultancy</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; background: #101a2b; color: #fff; margin: 0; }
        .dashboard-wrapper { display: flex; min-height: 100vh; }
        .sidebar {
            width: 260px;
            background: #c2185b;
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 0;
        }
        .sidebar .nav {
            padding: 2rem 0 0 0;
        }
        .sidebar .nav-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 2rem;
            color: #fff;
            text-decoration: none;
            font-size: 1.1rem;
            transition: background 0.2s;
        }
        .sidebar .nav-item.active, .sidebar .nav-item:hover {
            background: #ad1457;
        }
        .sidebar .nav-item i {
            font-size: 1.4rem;
        }
        .sidebar .user-section {
            padding: 2rem 1rem 1rem 1rem;
            text-align: center;
            border-top: 1px solid #ad1457;
        }
        .sidebar .user-section img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 0.5rem;
        }
        .sidebar .user-section .user-name {
            font-weight: bold;
            margin-bottom: 0.2rem;
        }
        .sidebar .user-section .user-role {
            font-size: 0.95rem;
            color: #ffe066;
        }
        .main-content {
            flex: 1;
            padding: 2rem;
            background: #101a2b;
            min-height: 100vh;
        }
        .dashboard-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            margin-bottom: 2rem;
        }
        .card {
            background: #232b41;
            border-radius: 12px;
            padding: 2rem;
            flex: 1 1 320px;
            min-width: 320px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        }
        .card h3 {
            color: #ffe066;
            margin-top: 0;
        }
        .card .stat {
            font-size: 2.2rem;
            color: #4ee476;
            font-weight: bold;
            margin: 1rem 0;
        }
        .card .sub {
            color: #fff;
            font-size: 1rem;
        }
        .chart-container {
            background: #232b41;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .newsletter-form textarea { width: 100%; height: 100px; margin-bottom: 1rem; }
        .newsletter-form input[type="text"] { width: 100%; margin-bottom: 1rem; }
        .newsletter-form button { background: #ffe066; color: #232b41; border: none; padding: 0.7rem 2rem; border-radius: 4px; font-weight: bold; cursor: pointer; }
        .newsletter-form button:hover { background: #e6c200; }
        .success { color: #4ee476; margin-bottom: 1rem; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 2rem; }
        th, td { border: 1px solid #333; padding: 8px; text-align: left; }
        th { background: #232b41; }
        tr:nth-child(even) { background: #222b3a; }
        @media (max-width: 900px) {
            .dashboard-cards { flex-direction: column; }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <div>
            <div class="nav">
                <a href="#" class="nav-item active"><i class="fa fa-gauge"></i> Reports</a>
                <a href="#subscribers" class="nav-item"><i class="fa fa-user-plus"></i> Subscribers</a>
                <a href="#messages" class="nav-item"><i class="fa fa-envelope"></i> Contact Messages</a>
                <a href="#newsletter" class="nav-item"><i class="fa fa-chart-line"></i> Campaign Statistics</a>
                <a href="#" class="nav-item"><i class="fa fa-users"></i> Users</a>
                <a href="#" class="nav-item"><i class="fa fa-gear"></i> Settings</a>
            </div>
        </div>
        <div class="user-section">
            <img src="https://randomuser.me/api/portraits/men/1.jpg" alt="Admin">
            <div class="user-name">Hello Admin</div>
            <div class="user-role">Administrator</div>
        </div>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <h1 style="color:#ffe066;">Campaign Statistics</h1>
        <div class="dashboard-cards">
            <div class="card">
                <h3>Subscribers</h3>
                <?php
                $conn = new mysqli("localhost", "root", "", "proagromark");
                $result = $conn->query("SELECT COUNT(*) as total FROM newsletter");
                $row = $result->fetch_assoc();
                $subscriber_count = $row['total'];
                $conn->close();
                ?>
                <div class="stat"><?= $subscriber_count ?></div>
                <div class="sub">Total Subscribers</div>
            </div>
            <div class="card">
                <h3>Reports</h3>
                <div class="sub">Sent: 100%</div>
                <div class="sub">Opened: 20%</div>
                <div class="sub">Clicked: 10%</div>
                <div class="sub">Engagement: 30%</div>
                <div class="sub">Interest: 30%</div>
                <div class="sub" style="margin-top:1rem;">Most Active Time:<br> <?= date('l, d F Y') ?> <br>10:00-11:00 AM</div>
            </div>
            <div class="card">
                <h3>Platforms</h3>
                <canvas id="platformsChart" width="180" height="120"></canvas>
                <div class="sub" style="margin-top:1rem;">
                    <span style="color:#ffe066;">Desktop</span> 80% &nbsp;
                    <span style="color:#e57373;">Tablet</span> 8% &nbsp;
                    <span style="color:#4ee476;">Mobile</span> 12%
                </div>
            </div>
            <div class="card">
                <h3>Interactions/Engagement</h3>
                <canvas id="engagementChart" width="180" height="120"></canvas>
                <div class="sub" style="margin-top:1rem;">
                    Sent: 50,000 &nbsp; Delivered: 40,000 &nbsp; Bounced: 15,000
                </div>
            </div>
        </div>
        <!-- Chart Section -->
        <div class="chart-container">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <h2 style="margin:0;">Subscriber Growth</h2>
                <div>
                    <button onclick="showChart('days')" style="margin-right:8px;">Days</button>
                    <button onclick="showChart('weeks')" style="margin-right:8px;">Weeks</button>
                    <button onclick="showChart('months')">Months</button>
                </div>
            </div>
            <canvas id="subscribersChart" height="80"></canvas>
        </div>
        <!-- Newsletter Sender -->
        <h2 id="newsletter">Send Newsletter</h2>
        <?php if (isset($_GET['sent'])): ?>
            <div class="success">Newsletter sent to all subscribers!</div>
        <?php endif; ?>
        <form class="newsletter-form" method="post" action="send_newsletter.php">
            <input type="text" name="subject" placeholder="Newsletter Subject" required>
            <textarea name="body" placeholder="Newsletter Content (HTML allowed)" required></textarea>
            <button type="submit">Send Newsletter</button>
        </form>
        <!-- Newsletter Subscribers -->
        <h2 id="subscribers">Newsletter Subscribers</h2>
        <table>
            <tr>
                <th>#</th>
                <th>Email</th>
                <th>Subscribed At</th>
            </tr>
            <?php
            $conn = new mysqli("localhost", "root", "", "proagromark");
            $result = $conn->query("SELECT id, email, created_at FROM newsletter ORDER BY id DESC");
            $i = 1;
            while ($row = $result->fetch_assoc()):
            ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= $row['created_at'] ?></td>
            </tr>
            <?php endwhile; $conn->close(); ?>
        </table>
        <!-- Contact Messages -->
        <h2 id="messages">Contact Messages</h2>
        <table>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Received At</th>
            </tr>
            <?php
            $conn = new mysqli("localhost", "root", "", "proagromark");
            $result = $conn->query("SELECT id, name, email, contact, subject, message, created_at FROM contacts ORDER BY id DESC");
            $i = 1;
            while ($row = $result->fetch_assoc()):
            ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['contact']) ?></td>
                <td><?= htmlspecialchars($row['subject']) ?></td>
                <td><?= htmlspecialchars($row['message']) ?></td>
                <td><?= $row['created_at'] ?></td>
            </tr>
            <?php endwhile; $conn->close(); ?>
        </table>
    </div>
</div>
<!-- Chart.js Script -->
<?php
// Prepare data for the chart (default: last 7 days)
$conn = new mysqli("localhost", "root", "", "proagromark");
$days = [];
$counts = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $days[] = $date;
    $result = $conn->query("SELECT COUNT(*) as cnt FROM newsletter WHERE DATE(created_at) = '$date'");
    $row = $result->fetch_assoc();
    $counts[] = (int)$row['cnt'];
}
$conn->close();
?>
<script>
let chart;
function showChart(interval) {
    fetch('subscriber_stats.php?interval=' + interval)
        .then(response => response.json())
        .then(data => {
            chart.data.labels = data.labels;
            chart.data.datasets[0].data = data.counts;
            chart.update();
        });
}
window.onload = function() {
    // Main subscriber growth chart
    const ctx = document.getElementById('subscribersChart').getContext('2d');
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($days) ?>,
            datasets: [{
                label: 'Subscribers',
                data: <?= json_encode($counts) ?>,
                borderColor: '#ffe066',
                backgroundColor: 'rgba(255,224,102,0.1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            scales: {
                x: { title: { display: true, text: 'Date' } },
                y: { title: { display: true, text: 'Subscribers' }, beginAtZero: true }
            }
        }
    });

    // Platforms chart (static demo data)
    new Chart(document.getElementById('platformsChart').getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: ['Desktop', 'Tablet', 'Mobile'],
            datasets: [{
                data: [80, 8, 12],
                backgroundColor: ['#ffe066', '#e57373', '#4ee476']
            }]
        },
        options: { plugins: { legend: { display: false } } }
    });

    // Engagement chart (static demo data)
    new Chart(document.getElementById('engagementChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ['Sent', 'Delivered', 'Bounced'],
            datasets: [{
                label: 'Count',
                data: [50000, 40000, 15000],
                backgroundColor: ['#ffe066', '#4ee476', '#e57373']
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
        }
    });
};
</script>
</body>
</html>