<?php
// filepath: c:\Users\Kelvin K. Nkoma\Desktop\Pro Agro Mark Consultancy\db_connect.php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'proagromark';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}
?>